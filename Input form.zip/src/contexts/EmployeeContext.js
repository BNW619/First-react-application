import {createContext, useEffect, useState} from 'react';
import { v4 as uuidv4 } from 'uuid';

export const EmployeeContext = createContext()

const EmployeeContextProvider  = (props) => {

    const [employees, setEmployees] = useState([
        {id:uuidv4(), name: 'Harry', email: 'harry@mail.com', address: '89 , jhor town', phone: '(92) 308-6998525'},
        {id:uuidv4(), name: 'jhon', email: 'jhon@mail.com', address: 'Obere Str. 57, Berlin, Afghanistan', phone: '(92) 308-6998525'},
        {id:uuidv4(), name: 'xeven', email: 'xeven@mail.com', address: '25, rue Lauriston, Paris, Lahore', phone: '(92) 308-699000'},
        {id:uuidv4(), name: 'ucp', email: 'ucp@mail.com', address: 'C/ Araquil, 67, Madrid, Karachi', phone: '(92) 308-6998215'},
        {id:uuidv4(), name: 'umt', email: 'umt@mail.com', address: 'Via Monte Bianco 34, Turin, Multan', phone: '(92) 308-69989633'}
])

useEffect(()=> {
    setEmployees(JSON.parse(localStorage.getItem('employees')))
},[])

useEffect(() => {
    localStorage.setItem('employees', JSON.stringify(employees));
})



const sortedEmployees = employees.sort((a,b)=>(a.name < b.name ? -1 : 1));



const addEmployee = (name, email, address, phone) => {
    setEmployees([...employees , {id:uuidv4(), name, email, address, phone}])
}

const deleteEmployee = (id) => {
    setEmployees(employees.filter(employee => employee.id !== id))
}

const updateEmployee = (id, updatedEmployee) => {
    setEmployees(employees.map((employee) => employee.id === id ? updatedEmployee : employee))
}

    return (
        <EmployeeContext.Provider value={{sortedEmployees, addEmployee, deleteEmployee, updateEmployee}}>
            {props.children}
        </EmployeeContext.Provider>
    )
}

export default EmployeeContextProvider;