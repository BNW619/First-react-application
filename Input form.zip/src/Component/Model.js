// import React, { useState } from "react";
// import Button from "react-bootstrap/Button";
// import Modal from "react-bootstrap/Modal";
// import Form from "react-bootstrap/Form";

// function Model() {
//     useState [userName, setUserName] = useState({
//         firstname:"",
//         Lastname:"",
//         email:"",
//         password:""
        
//     });
//   const [show, setShow] = useState(false);
//   const handleClose = () => setShow(false);
//   const handleShow = () => setShow(true);
//   const handleInput = () => {};
//   return (
//     <div>
//       <>
//         <Button variant="primary" onClick={handleShow}>
//           Launch static backdrop modal
//         </Button>

//         <Modal
//           show={show}
//           onHide={handleClose}
//           backdrop="static"
//           keyboard={false}
//         >
//           <Modal.Header closeButton>
//             <Modal.Title>Input Model form</Modal.Title>
//           </Modal.Header>
//           <Modal.Body>
//             <Form>
//               <Form.Group className="mb-3" controlId="formBasicEmail">
//                 <Form.Label>First Name</Form.Label>
//                 <Form.Control
//                   type="text"
//                   autocomplete="off"
//                   Name="firstname"
//                 //   value={userRegistraion.firstname}
//                   onChange={handleInput}
//                   placeholder="Enter your Name"
//                 />
//               </Form.Group>
//               <Form.Group className="mb-3" controlId="Name">
//                 <Form.Label>Last Name</Form.Label>
//                 <Form.Control
//                   autocomplete="off"
//                   type="name"
//                 //   value={userRegistraion.Lastname}

//                   onChange={handleInput}
//                   placeholder="Enter Your Last Name"
//                 />
//               </Form.Group>
//               <Form.Group className="mb-3" controlId="formBasicEmail">
//                 <Form.Label>Email address</Form.Label>
//                 <Form.Control
//                   type="email"
//                   name="email"
//                 //   value={userRegistraion.email}

//                   onChange={handleInput}
//                   placeholder="Enter email"
//                 />
//               </Form.Group>
//               <Form.Group className="mb-3" controlId="formBasicPassword">
//                 <Form.Label>Password</Form.Label>
//                 <Form.Control
//                   type="password"
//                   name="password"
//                 //   value={userRegistraion.password}

//                   onChange={handleInput}
//                   placeholder="Password"
//                 />
//               </Form.Group>
//               <Form.Group className="mb-3" controlId="formBasicCheckbox">
//                 <Form.Text className="text-muted">
//                   We'll never share your email with anyone else.
//                 </Form.Text>
//                 <Form.Check
//                   type="checkbox"
//                   name="email"
//                   onChange={handleInput}
//                   label="Check me out"
//                 />
//               </Form.Group>
//               <Button
//                 variant="primary"
//                 autocomplete="off"
//                 name="submit"
//                 type="submit"
//               >
//                 Submit
//               </Button>
//             </Form>
//           </Modal.Body>
//           <Modal.Footer>
//             <Button variant="secondary" onClick={handleClose}>
//               Close
//             </Button>
//           </Modal.Footer>
//         </Modal>
//       </>
//     </div>
//   );
// }
// export default Model;
