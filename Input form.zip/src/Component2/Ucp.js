import React from "react";
import { Button } from "react-bootstrap";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Hooksform from "../Component/Hooksform";
import MinInput from "../inputform/MinInput"
import {FcHome} from "react-icons/fc"

function Ucp() {
  return (
    <div>
      <div>
        <div class="ui stackable menu d-flex justify-content-evenly p-3 mb-5">
          <div class="">
            <img src="https://admin.umt.edu.pk/Media/Site/skt1/FileManager/2020/UMT%20Sialkot%20Logo.png" alt="" className="w-50" />
          </div>
          <a class="item">Features</a>
          <a class="item">Testimonials</a>
          <a class="item">Sign-in</a>
          <Link to="./">
        <Button className="d-flex text-center" variant="primary">
          <FcHome className="mt-1" />
          Home
        </Button>
        </Link>
        </div>
      </div>
      <div className="text-center p-5">
        <h1 className="mb-5">
          <b>Ucp Solution</b>
        </h1>
        <h3 className="mt-3">Shaping Technology For the Future</h3>
        <p className="mt-2">Growth. Innovation. Leadership.</p>
        <Link to="/MinInput">
          <button class="ui inverted orange button  mt-4"
          >LET'S CONNECT</button>
        </Link>
        <Link to="/Hooksform">
          <button class="ui inverted orange button  mt-4"
          >Simple Add To CONNECT</button>
        </Link>
      </div>
    </div>
  );
}

export default Ucp;
