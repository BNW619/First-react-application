import { BrowserRouter as Router, Switch, Route,  } from "react-router-dom";
import "./App.css";
// import Model from "./Component/Model";
import Homepage from "./Component/Homepage";
import Hooksform from "./Component/Hooksform";
import Xeven from "./Component2/Xeven";
import Ucp from "./Component2/Ucp";
import Umt from "./Component2/Umt";
import Medicalform from "./Medicalform/Medicalform";

// import Ucpform from "./Componet-form/Ucpform";
import MinInput from "./inputform/MinInput"


function App() {
  return (
    <div>
      
      {/* <Hooksform/>
      <Table/> */}
      <Router>
        <Switch>
          <Route exact path="/">
            <Homepage />
          </Route>       
          <Route exact path="/MinInput">
            <MinInput />
          </Route>
          <Route exact path="/Hooksform">
            <Hooksform />
          </Route>
          <Route exact path="/xeven"> 
            <Xeven />
          </Route>
          <Route exact path="/Ucp">
            <Ucp/>
          </Route>
          <Route exact path="/Umt">
            <Umt />
          </Route>
          <Route exact path="/Medicalform">
            <Medicalform />
          </Route>
        </Switch>
      </Router>
    </div>
  );
}
export default App;
