import EmployeeList from './EmployeeList';
import EmployeeContextProvider from '../contexts/EmployeeContext';

function MainInput() {
  return (
    <div className="container-xl">
      <div className="table-responsive">
        <div className="table-wrapper">
          <EmployeeContextProvider>
            <EmployeeList />
           
          </EmployeeContextProvider>
        </div>
      </div>
    </div>
  );
}

export default MainInput;
