import React, { useState } from "react";
import { Table } from "react-bootstrap";
// import { BsPlusSquareFill } from "react-icons/bs";
// import { RiDeleteBin5Line } from "react-icons/ri";
const Tables = (props) => {
  // const [userRegistraion, setUserRegistraion] = useState();
  // const deleteUser = (id) => {
  //   console.log("working");
  //   setUserRegistraion(userRegistraion.filter((user) => user.id !== id));
  // };
  return (
    <div className="home p-5 m-5">
      <Table striped bordered hover className="mlk ">
        <thead>
          <tr>
            <th className="th">#</th>
            <th className="th">Full Name</th>
            <th className="th">E-mail</th>
            <th className="th">Phone</th>
            <th className="th">Password</th>
          </tr>
        </thead>
        <tbody>
          {props.users.map((user, index) => {
            return (
              <tr>
                <td className="th">{index + 1}</td>
                <td className="th">{user.username}</td>
                <td className="th">{user.email}</td>
                <td className="th">{user.phone}</td>
                <td className="th">{user.password}</td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
};

export default Tables;
