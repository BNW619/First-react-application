import React, { useState } from "react";
import { Form, Button } from "react-bootstrap";
import Table from "./Table";

function Hooksform(props) {
  console.log(props);
  const [userRegistraion, setUserRegistraion] = useState({
    username: "",
    email: "",
    phone: "",
    password: "",
    
  });

  const [records, setRecords] = useState([]);

  const handleInput = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    console.log(name, value);

    setUserRegistraion({ ...userRegistraion, [name]: value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();

    const newRecord = {
      ...userRegistraion,
      id: new Date().getTime().toString(),
    };
    console.log(records);
    setRecords([...records, newRecord]);
    console.log(records);

    setUserRegistraion({ username: "", email: "", phone: "", password: "" });
  };
  return (
    <div className="from-hook container w-25 pt-5  w-100">
      <div className="divform mx-auto">      
        <section className="form ">
          <Form className=" pt-4 pb-4 p-5" action="" onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label htmlFor="username">FullName</Form.Label>
              <Form.Control
                className="w-100"
                type="text"
                autoComplete="off"
                value={userRegistraion.username}
                onChange={handleInput}
                name="username"
                id="username"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicPassword">
              <Form.Label htmlFor="email">email</Form.Label>
              <Form.Control
                type="text"
                autoComplete="off"
                value={userRegistraion.email}
                onChange={handleInput}
                name="email"
                id="email"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label htmlFor="phone">phone</Form.Label>
              <Form.Control
                type="text"
                autoComplete="off"
                value={userRegistraion.phone}
                onChange={handleInput}
                name="phone"
                id="phone"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicPassword">
              <Form.Label htmlFor="password">password</Form.Label>
              <Form.Control
                type="password"
                autoComplete="off"
                value={userRegistraion.password}
                onChange={handleInput}
                name="password"
                id="password"
              />
            </Form.Group>
            <Button variant="primary" type="submit">
              Submit
            </Button>
          </Form>
        </section>
      </div>
      <Table users={records}  />
    </div>
  );
}
export default Hooksform;
